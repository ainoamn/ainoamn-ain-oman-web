import Layout from "../components/layout/Layout";

export default function SearchPage(){
  return (
    <Layout>
      <h2 className="text-2xl font-semibold mb-4">نتائج البحث</h2>
      <div className="rounded-xl border dark:border-slate-700 p-4 bg-white dark:bg-slate-800">
        النتائج تظهر هنا...
      </div>
    </Layout>
  );
}
