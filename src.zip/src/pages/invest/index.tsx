// src/pages/invest/index.tsx
import Head from "next/head";
import Link from "next/link";
import { useMemo, useState } from "react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

// ---- i18n fallback ----
let useI18n: any;
try {
  useI18n = require("@/lib/i18n").useI18n;
} catch {
  useI18n = () => ({
    t: (k: string, d?: string) => ({
      "invest.title": "الاستثمار العقاري",
      "invest.subtitle": "فرص استثمارية مدروسة مع عوائد متوقعة وإدارة شفافة.",
      "invest.filter.all": "الكل",
      "invest.filter.reit": "صناديق عقارية (REITs)",
      "invest.filter.crowd": "استثمار تشاركي",
      "invest.filter.debt": "تمويل/دين عقاري",
      "invest.card.min": "الحد الأدنى",
      "invest.card.roi": "العائد المتوقع",
      "invest.card.duration": "المدة",
      "invest.card.location": "الموقع",
      "invest.card.learn": "تفاصيل الفرصة",
      "invest.note": "سيتم لاحقًا ربط الصفحة بواجهات تمويل واستثمار وربط مع البنوك.",
    } as Record<string, string>)[k] || d || k,
    lang: "ar",
    dir: "rtl",
  });
}

type Investment = {
  id: string;
  title: string;
  type: "reit" | "crowd" | "debt";
  min: number; // OMR
  roi: string; // e.g., "12% سنوي"
  duration: string; // e.g., "24 شهر"
  location: string;
  img: string;
  highlight?: string;
};

const MOCK: Investment[] = [
  {
    id: "INV-001",
    title: "مجمع شقق فاخرة قيد التطوير",
    type: "crowd",
    min: 1000,
    roi: "12% سنوي",
    duration: "24 شهر",
    location: "مسقط - الخوض",
    img: "https://images.unsplash.com/photo-1600585154154-1e4fb1c38d1d?q=80&w=1470&auto=format&fit=crop",
    highlight: "ضمانات إنجاز من المقاول",
  },
  {
    id: "INV-002",
    title: "REIT للتأجير السكني",
    type: "reit",
    min: 500,
    roi: "7.5% سنوي (توزيعات)",
    duration: "مفتوحة",
    location: "مسقط الكبرى",
    img: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?q=80&w=1470&auto=format&fit=crop",
    highlight: "تنويع عبر 120 وحدة",
  },
  {
    id: "INV-003",
    title: "سندات تمويل مشروع تجاري",
    type: "debt",
    min: 5000,
    roi: "10% ثابت",
    duration: "18 شهر",
    location: "نزوى",
    img: "https://images.unsplash.com/photo-1494526585095-c41746248156?q=80&w=1470&auto=format&fit=crop",
    highlight: "رهونات مسجلة",
  },
  {
    id: "INV-004",
    title: "مجمع فيلات للتجزئة",
    type: "crowd",
    min: 1500,
    roi: "13.5% سنوي",
    duration: "30 شهر",
    location: "ولاية بركاء",
    img: "https://images.unsplash.com/photo-1600573472591-ee6c8e69589e?q=80&w=1470&auto=format&fit=crop",
  },
];

export function Content() {
  const { t } = useI18n();
  const [type, setType] = useState<string>("all");
  const filtered = useMemo(
    () => MOCK.filter((x) => type === "all" || x.type === (type as any)),
    [type]
  );
  const fmt = (n: number) => new Intl.NumberFormat("ar-OM").format(n) + " ر.ع";

  return (
    <section className="py-8">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Hero */}
        <div className="mb-8 rounded-2xl bg-gradient-to-r from-teal-600 to-cyan-600 p-6 text-white shadow-lg">
          <h1 className="text-2xl font-bold">{t("invest.title")}</h1>
          <p className="opacity-95 mt-1">{t("invest.subtitle")}</p>
          <div className="mt-4 text-white/90 text-sm">{t("invest.note")}</div>
        </div>

        {/* Filters */}
        <div className="mb-6 flex flex-wrap gap-2">
          <button
            className={`rounded-full px-4 py-2 text-sm border ${type==="all"?"bg-teal-600 text-white border-teal-600":"bg-white text-slate-700 border-slate-200 hover:bg-slate-50"}`}
            onClick={() => setType("all")}
          >
            {t("invest.filter.all")}
          </button>
          <button
            className={`rounded-full px-4 py-2 text-sm border ${type==="reit"?"bg-teal-600 text-white border-teal-600":"bg-white text-slate-700 border-slate-200 hover:bg-slate-50"}`}
            onClick={() => setType("reit")}
          >
            {t("invest.filter.reit")}
          </button>
          <button
            className={`rounded-full px-4 py-2 text-sm border ${type==="crowd"?"bg-teal-600 text-white border-teal-600":"bg-white text-slate-700 border-slate-200 hover:bg-slate-50"}`}
            onClick={() => setType("crowd")}
          >
            {t("invest.filter.crowd")}
          </button>
          <button
            className={`rounded-full px-4 py-2 text-sm border ${type==="debt"?"bg-teal-600 text-white border-teal-600":"bg-white text-slate-700 border-slate-200 hover:bg-slate-50"}`}
            onClick={() => setType("debt")}
          >
            {t("invest.filter.debt")}
          </button>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((it) => (
            <article key={it.id} className="rounded-2xl overflow-hidden bg-white border shadow-sm hover:shadow-md transition">
              <div className="relative">
                <img src={it.img} alt={it.title} className="w-full h-56 object-cover" />
                <div className="absolute top-4 right-4">
                  <span className="rounded-full bg-white/90 text-slate-800 text-xs px-3 py-1 border">
                    {it.type === "reit" ? "REIT" : it.type === "crowd" ? "استثمار تشاركي" : "دين عقاري"}
                  </span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-lg font-bold text-slate-900 mb-1">{it.title}</h3>
                <div className="text-sm text-slate-500 mb-4">{t("invest.card.location")}: {it.location}</div>
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="rounded-lg bg-slate-100 p-3 text-center">
                    <div className="text-xs text-slate-500">{t("invest.card.min")}</div>
                    <div className="font-semibold">{fmt(it.min)}</div>
                  </div>
                  <div className="rounded-lg bg-slate-100 p-3 text-center">
                    <div className="text-xs text-slate-500">{t("invest.card.roi")}</div>
                    <div className="font-semibold text-emerald-700">{it.roi}</div>
                  </div>
                  <div className="rounded-lg bg-slate-100 p-3 text-center">
                    <div className="text-xs text-slate-500">{t("invest.card.duration")}</div>
                    <div className="font-semibold">{it.duration}</div>
                  </div>
                </div>
                {it.highlight && (
                  <div className="mb-4 rounded-lg bg-emerald-50 text-emerald-800 ring-1 ring-emerald-200 px-3 py-2 text-sm">
                    {it.highlight}
                  </div>
                )}
                <div className="flex gap-3">
                  <Link href={`/invest/${it.id}`} className="flex-1 text-center rounded-lg bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 font-medium">
                    {t("invest.card.learn")}
                  </Link>
                  <Link href="/contact" className="rounded-lg border bg-white px-4 py-2 text-slate-800 hover:bg-slate-50">
                    تواصل
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export default function Page() {
  const { dir } = useI18n();
  return (
    <main dir={dir} className="min-h-screen bg-slate-50 flex flex-col">
      <Head>
        <title>الاستثمار | Ain Oman</title>
      </Head>
      <Header />
      <div className="flex-1">
        <Content />
      </div>
      <Footer />
    </main>
  );
}
