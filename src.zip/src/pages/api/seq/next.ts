// src/pages/api/seq/next.ts
import type { NextApiRequest, NextApiResponse } from "next";
import { getNextId } from "../../../lib/id";

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  const ns = (req.query.ns as string) as any;
  try {
    const id = getNextId(ns);
    res.status(200).json({ ns, id });
  } catch (e:any) {
    res.status(400).json({ error: "Invalid namespace", message: e?.message });
  }
}