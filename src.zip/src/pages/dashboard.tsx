import Layout from "../components/layout/Layout";

export default function Dashboard(){
  return (
    <Layout>
      <h2 className="text-2xl font-bold mb-2">لوحة البيانات</h2>
      <p>عند ربط تسجيل الدخول لاحقًا، سيتم تحويل المستخدم هنا تلقائيًا بعد التحقق.</p>
    </Layout>
  );
}
