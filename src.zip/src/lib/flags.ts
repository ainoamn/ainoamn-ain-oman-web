import flags from '../../config/feature-flags.json'; export default flags as any;
