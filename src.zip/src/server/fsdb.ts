// src/server/fsdb.ts
import fs from "fs";
import path from "path";

const dataDir = path.join(process.cwd(), ".data");

function ensureDir() {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
}

export function readJson<T>(file: string, fallback: T): T {
  try {
    ensureDir();
    const p = path.join(dataDir, file);
    if (!fs.existsSync(p)) return fallback;
    const raw = fs.readFileSync(p, "utf8");
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function writeJson<T>(file: string, data: T): void {
  ensureDir();
  const p = path.join(dataDir, file);
  fs.writeFileSync(p, JSON.stringify(data, null, 2), "utf8");
}
